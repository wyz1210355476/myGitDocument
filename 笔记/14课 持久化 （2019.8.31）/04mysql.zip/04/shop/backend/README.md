#SHOPPING CART WITH SEQUELIZE(MYSQL)
                                                                                                                                  

Shopping Cart made in nodejs, expressjs and ejs

Create a .env file in te root directory with the following environment variables set:
DB_USER
DB_Database
DB_PWD


To install, first run:
npm install

The entry point of the app is app.js

The app can be ran by calling:
npm start

which alternatively calls:
nodemon app.js
