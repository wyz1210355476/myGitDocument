module.exports = {
    database: 'shop',
    username: 'root',
    password:'example',
    host:'localhost'
 };